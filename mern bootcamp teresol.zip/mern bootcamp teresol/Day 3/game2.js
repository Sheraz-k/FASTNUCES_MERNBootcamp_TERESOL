// Rock paper scissors using long code
const prompt = require('prompt-sync')();
console.log('ROCK, PAPER, and SCISSORS GAME.');
let rock = 'rock';
let paper = 'paper';
let scissors = 'scissors';
let firstUser = prompt('Enter your first option: ').toLowerCase();
if(firstUser === rock || firstUser === scissors || firstUser === paper)
{
console.log(`You have chosen the ${firstUser}`);
}
else{
console.log('You have chosen a wrong option. Please enter rock, paper or scissors.');
firstUser = prompt('Enter your first option: ').toLowerCase();
}
let secondUser = prompt('Enter your second option: ').toLowerCase();
if(secondUser === rock || secondUser === scissors || secondUser === paper)
{
console.log(`You have chosen the ${secondUser}`);
}
else{
console.log('You have chosen a wrong option. Please enter rock, paper or scissors.');
secondUser = prompt('Enter your second option: ').toLowerCase();
}

if(firstUser === rock && secondUser === paper)
{
console.log(`The winner is ${secondUser}.`);
}
else if (firstUser === paper && secondUser === rock)
{
console.log(`The winner is ${firstUser}.`);
}
else if (firstUser === scissors && secondUser === rock)
{
console.log(`The winner is ${secondUser}.`);
}
else if (firstUser === rock && secondUser === scissors)
{
console.log(`The winner is ${firstUser}.`);
}
else if (firstUser === paper && secondUser === scissors)
{
console.log(`The winner is ${secondUser}.`);
}
else if (firstUser === scissors && secondUser === paper)
{
console.log(`The winner is ${firstUser}.`);
}
else {
console.log("It's a tie!")
}