const PromptSync = require("prompt-sync")();
console.log("Select only two options Rock, Paper and Scissor Games")
let r = rock;
let p = paper;
let s = scissor;

let firstPlayer = prompt("First Player select option : ");
if(firstPlayer  )
