const names = ["wasif", "naveed", "waqas", "haseeb"]
console.log(names[1]);
console.log(names);
// names[44] = "ali";

let lng=names.length;
console.log(lng)

let po = names.pop(3)
console.log(po)
let na = names[names.length-1]
console.log(na)
let randomNumber = Math.floor(Math.random() * 3) + 1;
console.log(randomNumber);
