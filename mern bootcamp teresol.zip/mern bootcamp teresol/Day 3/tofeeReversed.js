// const input = require("prompt-sync")();


// //SIMPLE CODE 

// const mychoices = ["rock", "paper", "scissor"];


// let player1 = input("Please Enter Player1 Name : ");
// let player2 = "Computer";

// let p1choice = input(`${player1} Enter your choice (Rock or Paper or Scissor): `).toLowerCase();
// let p2choice = Number(Math.floor(Math.random() * 3)); //limit random int to 0-2


// if(p1choice == p2choice){
//     console.log("Tie");
// }
// else if((p1choice == "rock" &&  p2choice == "scissor") || (p1choice == "paper" &&  p2choice == "rock") || (p1choice == "scissor" &&  p2choice == "paper")){

//     console.log(`Hurrah !! ${player1} Wins...! `);
// }
// else{
//     console.log(`Alas!! ${player2} Wins...! Try Again`);
// }


// const myArray = ["hassan", "saad", "sumama", "john"];



// function reverseArray(arr) {
//   let start = 0;
//   let end = arr.length - 1;

//   while (start < end) {
//     let temp = arr[start];
//     arr[start] = arr[end];
//     arr[end] = temp;

//     start++;
//     end--;
//   }

//   return arr;
// }

// console.log(reverseArray(myArray));



// let arr= ['a','ali',1];
// let new_string = " "
// let i=arr.length -1
// while( i>=0){

// new_string +=arr[i]
// i--

// }
// console.log(new_string)

let arr= ['a','ali',1];
let new_string = ""
let i=arr.length -1
while( i>=0){

new_string +=arr[i]
i--

}
console.log(new_string)