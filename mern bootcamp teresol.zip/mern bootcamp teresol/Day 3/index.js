// Check undefined or null by --> ??
// let height =null;
// height = height ?? 1;

// const prompt = require('prompt-sync')()
// let num = Number(prompt("Enter you number"));
// if (num % 2 == 0){
//     console.log("Number is even")
// }

// // program to check if the number is even or odd
// // take input from the user
// const number = prompt("Enter a number: ");

// //check if the number is even
// if(number % 2 == 0) {
//     console.log("The number is even.");
// }

// // if the number is odd
// else {
//     console.log("The number is odd.");
// }

let counter = 1
while (counter < 6){
console.log("site")
counter++;
}

//Rock Paper Scissor Game
console.log("\nPress:\n'R' for Rock\n'P' for Paper\n'S' for Scissors");
const prompt = require('prompt-sync')(); 

console.log("\nEnter choice:")
let player1 = String(prompt('Player 1: '));
player1 = player1.toUpperCase();
let player2 = String(prompt('Player 2: '));
player2 = player2.toUpperCase();
let result;

if(player1 == player2)
{
    console.log("\nTie");
}
else if((player1 == 'R' && player2 == 'S') || (player1 == 'S' && player2 == 'R'))
{
    console.log("\nPlayer with Rock wins");
}
else if((player1 == 'R' && player2 == 'P') || (player1 == 'P' && player2 == 'R'))
{
    console.log("\nPlayer with Paper wins");
}
else if((player1 == 'S' && player2 == 'P') || (player1 == 'P' && player2 == 'S'))
{
    console.log("\nPlayer with Scissor wins");
}
else{
    console.log("Invalid choice")
}


/**
 * @author Saleem
 * @todo {Rock Secissor Game}
 */

/**
 * Rock scissor game
 * @var p1  player 1
 * @var p2 palyer 2
 * @return {answer}
 */

const prompt = require('prompt-sync')(); //initilizing library and saving it in variable

let p1 = prompt('Enter choice for player 1 : ');
let p2 = prompt('Enter choice for player 2 : ');

let rock = 'rock';
let scissor = 'scissor';
let papper = 'paper';

if ((p1 == rock && p2 == scissor) || (p1 == scissor && p2 == papper ) || (p1 == papper && p2 == rock )) {
    console.log('Player 1 wins');   
}else if ((p2 == rock && p1 == scissor) || (p2 == scissor && p1 == papper ) || (p2 == papper && p1 == rock )) {
    console.log('Player 2 wins');   
}else if (p1 == p2){
    console.log('Tie, Try again');
}else{
    console.log('Invalid choice entered');
}

/*

*/
const prompt = require("prompt-sync")();
let player1 = prompt(
  "Player 1 Choose Option s for Scissor, Option r for Rock, Option p for Paper "
);
let player2 = prompt(
  "Player 2 Choose Option s for Scissor, Option r for Rock, Option p for Paper "
);

if (
  (player1 == "s" && player2 == "p") ||
  (player1 == "r" && player2 == "s") ||
  (player1 == "p" && player2 == "r")
) {
  console.log("Player 1 Wins");
} else if (
  (player2 == "s" && player1 == "p") ||
  (player2 == "r" && player1 == "s") ||
  (player2 == "p" && player1 == "r")
) {
  console.log("Player 2 Wins");
} else {
  console.log("Match Draw");
}