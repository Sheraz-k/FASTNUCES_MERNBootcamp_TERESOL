// let arrary = ["paper","scissors","rock"]
// let randomNumber = Math.floor(Math.random() * 3) + 1;
// console.log(randomNumber);

// let values = ["paper","scissors","rock"];
// console.log(values[0].length)
// let values = [0,1,2]
// let randomIndex = Math.floor(Math.random() * values.length);
// let randomElement = values[randomIndex];
// console.log(randomElement);

// let arr = [1, 2, 3, 4, 5];
// let randomIndex = Math.floor(Math.random() * arr.length);
// // let randomElement = arr[randomIndex];
// console.log(randomIndex);


// let prompt = require('prompt-sync')();

// const per = ['R', 'P', 'S']
// let rand = Math.random()
// console.log(rand)
// let idx
// if (rand > 0 && rand < 0.3) {
//     idx = 0
// }
// else if (rand > 0.3 && rand < 0.6) {
//     idx = 1
// }
// else {
//     idx = 2
// }

// idx = 0

// console.log("Rock:R\nPaper:P\nScissor:S")
// let per1 = prompt("Enter your Choice : ")
// let com = per[idx]
// console.log("Computer choice: "+com)

// if ((per1 === 'R' && com === 'P') || (per1 === 'P' && com === 'S') || (per1 === 'S' && com === 'R')) {
//     console.log("Computer win")
// }
// else if ((per1 === 'P' && com === 'R') || (per1 === 'S' && com === 'P') || (per1 === 'R' && com === 'S')) {
//     console.log("person  win")
// }
// else if (per1 == com) {
//     console.log("match tie")
// }
// else {
//     console.log("Please select Valid Choice")
// }


// const str = ['Life, the'];

// console.log(`${str} ${str.length}`);

//Reverse number program

let number = 123456789;

// Initializing the result variable 
let result = 0;

while(number>0){
    // Getting the rightmost digit
    rightmost = number%10;
    
    result = result*10 + rightmost;
    
    // Removing the rightmost digit from the number
    number = Math.floor(number/10);
}
console.log("Reversed number is : " + result)