console.log("Today learning install node");

let name = "Zia";
console.log(name);