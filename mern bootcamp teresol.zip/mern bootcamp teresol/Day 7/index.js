// function greeting(){
//     console.log("Greeting of day")
//     var result=console.log(0.2 + 0.1)
//     return result   //now resul call in variable below function 
// }
// // let vari = greeting()
// greeting()
// //if want two more time print
// // greeting()
// // greeting()
// console.log(typeof greeting)    //check data type
// console.log(typeof vari)


// myfunc()    //through error not work hoisting method
//function expression (function declear by variable) exp function cannot use above 
// let myfunc = function greeting(){
//     console.log("Greeting of day")
//     var result=console.log(0.2 + 0.1)
//     return result   //now resul call in variable below function 
// }
// myfunc()
// console.log(typeof myfunc)


//call back function
// function main(){
//     let a = 0.1 + 0.3;
//     let result = b()
//     return function b(){
//         let b = 1+1;
//     }
// }


//rest parameters 
// function unlimited_parameter(...data){
//     let vari = data[0]
// }
// unlimited_parameter (1,2,3,4,5,6)


// function sum(...numbers) {
//     let result = 0;
//     for (const number of numbers) {
//       result += number;
//     }
//     return result;
//   }
  
//   console.log(sum(1, 2, 3));
//   // Expected output: 6
  
//   console.log(sum(1, 2, 3, 4));
//   // Expected output: 10

// function calculatePow(base, exponent){
// // let result = 3*3;
//     return base*exponent;
// }
// calculatePow()

// Arrow function, it is more readable
// (args)=> expression
// let power = (base, exponent) => base**exponent; //for two parameter
// console.log(power(3,5))


// let shortend = base => base * base;
// console.log(shortend(5))

 
// let helloo = hello = () => {
//     return "Hello World!";
//   }
// console.log(helloo())


let do_something = (a,b) =>{
    return "something"
}
console.log(do_something(3,6))