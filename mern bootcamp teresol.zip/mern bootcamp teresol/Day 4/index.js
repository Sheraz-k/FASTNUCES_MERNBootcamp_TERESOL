// let arr = [3,5,6,8]
// let sum = 0;
// for (let  count = 0; count<=arr.length; count++){
//   if (arr[count] % 2 === 0) {
//     sum += arr[count];
//     // break
//     // continue
//   }
// }
// console.log(sum);

// sum of even number from array

// const numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
// let sum = 0;

// for (let i = 0; i < numbers.length; i++) {
//   if (numbers[i] % 2 !== 0) {
//     sum += numbers[i];
//     continue
//   }
// }
// console.log(sum);

// const numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
// let sum = 0;

// for (let i = 0; i < numbers.length; i++) {
//   if (numbers[i] % 2 === 0) {
//     sum += numbers[i];
//     // break continous
//   }
// }
// console.log(sum);


// for......of...
// for(const iterate of Object){   //for 'of' loop, for 'each' loop

// }

// let num = "012345678"
                // for (let index = 0; index < num.length; index++){
                //   let value = numbers[index]
                // }
// for(let letter of num){
//   console.log(letter)
// }

// for (let char of "hello"){
//   console.log(char)
// }

// print even number
// let num = "012345678"
// for(let letter of num){
//   if(letter % 2 == 0)
//   console.log(letter)
// }


// function encrypt(plaintext, key) {
//   var cyphertext = "";
//   for (var i = 0; i < plaintext.length; i++) {
//       var charCode = plaintext.charCodeAt(i);
//       cyphertext += String.fromCharCode(charCode + key);
//   }
//   return cyphertext;
// }

// var plaintext = "hello";
// var key = 5;
// var cyphertext = encrypt(plaintext, key);
// console.log("Original Text: " + plaintext);
// console.log("Cypher Text: " + cyphertext);

// function caesarCipher(str, shift) {
//   var result = "";
//   for (var i = 0; i < str.length; i++) {
//     var char = str[i];
//     if (char.match(/[a-z]/i)) {
//       var code = str.charCodeAt(i);
//       if ((code >= 65) && (code <= 90)) {
//         char = String.fromCharCode(((code - 65 + shift) % 26) + 65);
//       } else if ((code >= 97) && (code <= 122)) {
//         char = String.fromCharCode(((code - 97 + shift) % 26) + 97);
//       }
//     }
//     result += char;
//   }
//   return result;
// }

// console.log(caesarCipher("abc", 2));


// var str = "hello";
// var shift = 3;
// var newString = "";

// for (var i = 0; i < str.length; i++) {
//   var char = str[i];
//   var charCode = str.charCodeAt(i);
//   if (charCode >= 65 && charCode <= 90) {
//     char = String.fromCharCode((charCode - 65 + shift) % 26 + 65);
//   } else if (charCode >= 97 && charCode <= 122) {
//     char = String.fromCharCode((charCode - 97 + shift) % 26 + 97);
//   }
//   newString += char;
// }
// console.log(newString);


// Enter string by user and convert into cypher
// let prompt = require('prompt-sync')();
// var str = prompt("Enter a string to encrypt:");
// var shift = prompt("Enter the shift value:");
// var newString = "";

// for (var i = 0; i < str.length; i++) {
//   var char = str[i];
//   var charCode = str.charCodeAt(i);
//   if (charCode >= 65 && charCode <= 90) {
//     char = String.fromCharCode((charCode - 65 + shift) % 26 + 65);
//   } else if (charCode >= 97 && charCode <= 122) {
//     char = String.fromCharCode((charCode - 97 + shift) % 26 + 97);
//   }
//   newString += char;
// }
// console.log(newString);


// let str_val = 'abcdefghijklmnopqrstuvwxyz';
// let nameStr = 'ali';
// let cypher = "";
// for (let newVal of nameStr){
//     for(let i=0; i<str_val.length; i++){
//         if(newVal == str_val[i]){
//             cypher += str_val [i + 2];
//         }
 
//     }
// }

// console.log (cypher)



