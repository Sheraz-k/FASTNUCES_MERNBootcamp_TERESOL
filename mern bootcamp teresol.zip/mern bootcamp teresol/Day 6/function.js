// var name1 = "my name global ";   //global scope variable
// function time_saving(user_data){    //variable by parameter
//     // var name = "my name";   //local scope variable
//     console.log(user_data)  //passed by parameters
//     console.log(name1)  //globally declared
//     console.log("you have logged out!!!")
//     user_data +='1'
// }

// name1 +='1'

// //function call ---(parameters)
// time_saving(name1)
// console.log(name1)

// function of Sum
// let sum = '' //variable shadowing
// function myFunction(val1, val2, val3) {
//   // return val1 + val2 + val3;
//   let sum = val1+val2+val3;
//   return sum
// }
// let sum = myFunction(3, 5, 2);
// console.log(sum);


//using different operator and return object
// function myFunction(val1, val2, val3) {
//      let sum1 = val1 + val2 + val3;
//      let sub1 = val1 + val2 - val3;
//      let Multi = val1 * val2 + val3;
//     return {sum1, sub1, Multi};
//   }
//   let sum = myFunction(3, 5, 2);
//   let sub = myFunction(3, 5, 6);
//   let mul = myFunction(3,2,1);
  
//   console.log(sum);
//   console.log(sub);
//   console.log(mul);


// ternary operator
// let num = 45;
// console.log((num == undefined)?1:num);


// // let sum = '' //variable shadowing
// function myFunction(val1, val2) {
//   // return val1 + val2 + val3;
//   let sum = val1+val2;
//   return sum
// }
// let sum = myFunction(3);
// console.log(sum);
  
  
// function calcSum(num1, num2) {
//   if (num2== undefined) {
//       num2=434
//   }
//   let sum=  num1+num2
//   return {sum, num1, num2};

// }
// let sum= calcSum(1);
// console.log(sum);


function login (email, name, password){
  email = "abc@gmail.com";
  password = 123;
}

login();