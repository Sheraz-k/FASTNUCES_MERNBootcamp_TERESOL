// function login(username,email, password) {
//     if (username === "admin" && email === "abc@gmail.com" && password === "password") {
//       return "Login successful";
//     } else {
//       return "Login failed";
//     }
//   }
  
//   const result = login("admin","email","password");
//   console.log(result);


// let prompt = require('prompt-sync')();
// let email = prompt("Enter your email :");
// let pass = prompt("Enter your password :")
// function login(email,pass){
//     if(email.includes("@") && email.includes("com")){
//     return console.log('Valid data');
// }else{
//     return console.log('Invalid data');
// }
// }
// login(email,pass);



  