// let prompt=require('prompt-sync')();
// let fav_color=("Select your fav color...");
// switch(fav_color) {
//   case 1:
//     console.log("")
//     break;
//   case 2:
//     // code block
//     break;
//   default:
//     // it will run nothing else runs
// }

//switch program select day of week
let prompt =require("prompt-sync")();
let day = +(prompt("Enter number from 2 to 7 and display week day = "));
switch (day) {
  case 2:
    console.log("Tuesday");
    break;
  case 3:
    console.log("Wednesday");
    // break;
  case 4:
    console.log("Thursday");
    // break;
  case 5:
    console.log("Friday");
    break;
  case 6:
    console.log("Saturday");
    break;
  case 7:
    console.log("Sunday");
    break;
  default:
    console.log("Invalid value");
}
