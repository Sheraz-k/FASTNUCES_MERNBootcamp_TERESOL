// let prompt = require(prompt-sync)();
let num = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20]
// let enter_number = prompt("Enter your number");
for(let i=0; i< num.length; i++){
    if(num[i] % 3 == 0 && num [i] % 5 ==0){
        console.log("Fizz Buzz");
        num[i]="Fizz Buzz";
    }
    else if (num[i] % 3 == 0){
        console.log("Fizz");
        num[i]="Fizz";
    }
    else if (num[i] % 5 == 0){
        console.log("Fizz");
        num[i] = "Buzz";
    }
}
console.log(num)

// 90 > not good enough
// 80 > okay
// 70 > cool







