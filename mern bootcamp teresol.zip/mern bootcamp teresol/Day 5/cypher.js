const PromptSync = require("prompt-sync")();
let str_val = 'abcdefghijklmnopqrstuvwxyz';
let entr_Str = PromptSync("Enter your string: ")
// let nameStr = 'zia is here'; //use .include method for space
// let cypher = " ";
let encoded = "";
for (let newVal of entr_Str){
    for(let i=1; i<=26; i++){
        if(newVal == str_val[i]){           
            // cypher += str_val [i + 2];
            for (let letter of entr_Str) {
                    position = (str_val.indexOf(letter) - i +26) % 26;
                    encoded += str_val[position];
                    console.log(`encrypted text: ${encoded}`);
            }
               
        }
 
    }
}
 
// console.log (cypher)


// encryptor
// let alphabet = "abcdefghijklmnopqrstuvwxyz";
// let plain_text = "z";
// // let plain_text = "mjgfajtauppatipsuaupacfatfsjpvtabmmauifaujnf";
// // key = 1;
// let encoded = "";
// for (let letter of plain_text) {
//     position = (alphabet.indexOf(letter) - index +26) % 26;
//     encoded += alphabet[position];
// }
// console.log(`encrypted text: ${encoded}`);
