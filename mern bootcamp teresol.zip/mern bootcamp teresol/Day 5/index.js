// let num = [2, 3, 4, 5, 6];

// for(){
// }

//for...of loop use for ite
// for (let number of num) {
//   let index = num.indexOf(number);
//   console.log(index);
  //-1
// }

//for...in loop use for data access
//when data in pair use object
// let student_obj = {
//   name: "Ali", //key value pair
//   age: "14",
// };

// for (const key in student_obj) {
  // student_obj[key]
// }


//By using object
// const person = { 
//     fname: "Ali", 
//     lname: "Shah", 
//     age: 25 
// };

// let text = " ";
// for (let x in person) {
//   text += person[x] + " ";
//     console.log(person[key])
// }

// console.log(text)

// Do while loop use
// let counter = 0
// do{
//     console.log("I will print")
//     counter++
// } while(counter < 4);



