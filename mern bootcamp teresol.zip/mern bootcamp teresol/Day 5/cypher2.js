// // encryptor
// let alphabet = "abcdefghijklmnopqrstuvwxyz";
// let plain_text = "edc";
// // let plain_text = "mjgfajtauppatipsuaupacfatfsjpvtabmmauifaujnf";

// // key = 5;
// let encoded = "";

    
//     for (let letter of plain_text) {
//         for (let index = 1; index <= 26; index++) {
           
//             position = (alphabet.indexOf(letter) - index+26) % 26;
//         encoded += alphabet[position];
//         console.log(`Decrypted Text: ${encoded} and key is: ${index}`);
            
//         }
        
//     }
    


// console.log(`encrypted text: ${encoded}`);






// // encryptor
let alphabet = "abcdefghijklmnopqrstuvwxyz";
// let plain_text = " hello wali!";

// key = 25;
let encoded = "";
// for (let letter of plain_text) {
//     if(alphabet.indexOf(letter)==-1){
//         encoded+=letter;
//         continue;
//     }
//     position = (alphabet.indexOf(letter) + key+26) % 26;
//     encoded += alphabet[position];
// }
// console.log(`encrypted text: ${encoded}`);

let prompt=require('prompt-sync')();
 encoded=prompt('Please enter the encrpyted text: ');
//  life is too short to be serious all the time
//  so if you cant laugh at yourself call me i ll laugh at you
//  why was the math book sad? because it had too many problems

//encoded="gdkkn vz";
let decodeee="";
for(let i=1;i<=26;i++){

    for (let letter of encoded) {
        if(alphabet.indexOf(letter)==-1){
            decode+=letter;
            continue;
        }
        position = (alphabet.indexOf(letter) - i+26) % 26;
        decode += alphabet[position];
    }
    console.log(` ${decodeee}    ------------ the key is ${i}`);
    decodeee="";
}