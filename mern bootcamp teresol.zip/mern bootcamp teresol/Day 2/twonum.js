//prompt byde
const prompt = require('prompt-sync')();
// const num1 = Number(prompt("Enter first Num :"));
// const num2 = Number(prompt("Enter 2nd Num :"));
const num1 = (prompt("Enter first Num :"));
const num2 = (prompt("Enter 2nd Num :"));
const num3 = (prompt("Enter 3rd Num :"));
const num4 = true
// const sum = Number(num1) + Number(num2)  Number(num3) + Number(num4);
const sum = Number(num1) + Number(num2)  - (num3) + Number(num4);
// const sum1 = (num1) + (num2) + (num3) + Number(num4);
// let sum;
// console.log(`Total number is :${sum1}`)
console.log(`Total number is :${sum}`)
console.log(typeof sum1)
val = true
console.log(typeof val)
// console.log(typeof sum)

//number + string = string  [here answer will be string]