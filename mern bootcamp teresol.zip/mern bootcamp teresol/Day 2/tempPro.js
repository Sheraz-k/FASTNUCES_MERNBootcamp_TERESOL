const ziakhan = require ('prompt-sync')();
//Fahrenheit to Celsius conversion
const temF = ziakhan('Enter temp. in Fahrenheit : ');
// Celsius to Fahrenheit conversion
const temC = ziakhan('Enter temp. in Celsius : ');

const temFtoC = (temF-32) * 5/9;
console.log(`${temF} Fahrenheit to Celsius conversion : ${temFtoC}`);
console.log(typeof temC) //if give us error it is 'NaN' because string calculation with number show not a number


const temCtoF = temC*9/5+32;
console.log(`${temC} Celsius to Fahrenheit conversion : ${temCtoF}`);