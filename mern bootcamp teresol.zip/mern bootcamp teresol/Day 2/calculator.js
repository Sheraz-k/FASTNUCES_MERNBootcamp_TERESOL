const prompt = require('prompt-sync')()
let num1 = prompt("Enter your first number : ")
let num2 = prompt("Enter your second number : ")
let sign = prompt("enter operator =");
if (sign == 'a'){
    console.log (Number(num1) + Number(num2))
}
if (sign == 'b'){
    console.log (Number(num1) - Number(num2))
}
if (sign == 'c'){
    console.log (Number(num1) * Number(num2))
}
if (sign == 'd'){
    console.log (Number(num1) / Number(num2))
}
