// //Fahrenheit to Celsius conversion
// let temF = 50;
// let temFtoC = (temF-32) * 5/9;
// console.log( temF ,"Fahrenheit to Celsius conversion :" ,temFtoC , "Celsius");

// // Celsius to Fahrenheit conversion
// let temC = 40;
// let temCtoF = temC*9/5+32;
// console.log(temC ,"Celsius to Fahrenheit conversion :" , temCtoF , "Fahrenheit");

// let num1 = 2384762348723648237462348n;
// let num2 = 565654;
// // let num3 = num1*num2
// // console.log(num3);
// // console.log(num1 * 2n)
// console.log(typeof num1)
// console.log(typeof num2)

// let myName = "Zia";
// let contact = "03000044555";

// console.log(`My name is ${myName} and contact number is : ${contact}`)
// console.log("My name is:" ,myName, "and contact number is :" ,Number(contact) )

// const PI =3.142
// pi = 3.444;
// console.log (PI)

//npm install prompt-sync
const prompt = require('prompt-sync')();    //'import library by "require" key word' use for fetch data from 'prompt-sync' libaary in current file 
// const name = prompt ('What is your name?')
// console.log (`Hey ther ${name}`)

const age = prompt()
let fname = prompt('Enter your first name :')
let lname = prompt('Enter your last name :')
console.log(`My name is "${fname}${lname}" and age is ${age}`)


